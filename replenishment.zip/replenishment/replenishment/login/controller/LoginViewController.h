//
//  LoginViewController.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "loginTextFiled.h"

@interface LoginViewController : UIViewController

@property(nonatomic,strong)loginTextFiled *nameField;
@property(nonatomic,strong)loginTextFiled *passField;

@end
