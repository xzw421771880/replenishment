//
//  LoginViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "LoginViewController.h"
#import "Help.h"

#import "AppDelegate.h"


@interface LoginViewController ()<UITextFieldDelegate>

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    self.navigationController.navigationBarHidden =YES;
    
    
    [self addBackGrand];//背景
    
    [self addtextField];//输入框
    
    [self addLogin];//登录
    
    // Do any additional setup after loading the view.
}


//背景
-(void)addBackGrand
{
    UIImageView *backView=[[UIImageView alloc]initWithFrame:self.view.bounds];
    backView.image=[UIImage imageNamed:@"denglu_bg"];
    [self.view addSubview:backView];
    
    UIImageView *teaImage=[[UIImageView alloc]initWithFrame:Frame(70, 130, WIDTH-140, 60)];
    teaImage.image=[UIImage imageNamed:@"chaxiang"];
    [teaImage keep];
    [self.view addSubview:teaImage];
    
}


//输入框
-(void)addtextField
{
    NSArray *imageAry=@[@"yong_hu_ming",@"mi_ma"];
    for (int i=0; i<2; i++) {
        loginTextFiled *view=[[loginTextFiled alloc]initWithFrame:Frame(40, 250+i*65, WIDTH-80, 40)];
        [self.view addSubview:view];
//        view.backgroundColor=[UIColor whiteColor];
        view.imageView.image=[UIImage imageNamed:imageAry[i]];
        view.textField.delegate=self;
        if (i==0) {
            self.nameField=view;
            view.textField.keyboardType =UIKeyboardTypeNumberPad;
            self.nameField.textField.placeholder=@"请输入用户名";
        }else
        {
            self.passField=view;
            view.textField.secureTextEntry=YES;
            view.textField.keyboardType =UIKeyboardTypeASCIICapable;
            self.passField.textField.placeholder=@"请输入密码";
        }
    }
}



#pragma mark - 登录---
- (void)addLogin
{
    UIButton *but =[UIButton buttonWithType:UIButtonTypeCustom];
    but.frame=Frame(40, 410, WIDTH-80, 40);
    [but setTitle:@"登录" forState:UIControlStateNormal];
    but.backgroundColor=HOMECOLOR;
    [but setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [but addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:but];
    
    
    but.layer.cornerRadius =3;
    but.layer.masksToBounds =YES;
}

- (void)loginAction
{
    
    
    if (self.nameField.textField.text.length==0) {
        [self alertWith:@"用户名不能为空"];
        return;
    }
    
    if (self.passField.textField.text.length==0) {
        [self alertWith:@"用户密码不能为空"];
        return;
    }
    
    if (![Help CheckPhoneNumInput:self.nameField.textField.text]) {
        [self alertWith:@"用户名格式不正确"];
        return;
    }
    NSLog(@"login");
    
    NSMutableDictionary *user=[[NSMutableDictionary alloc]init];
//    json[@"driver"];
    [user setObject:self.passField.textField.text forKey:@"pw"];
    [user setObject:self.passField.textField.text forKey:@"name"];
    [[NSUserDefaults standardUserDefaults] setObject:user forKey:@"user"];
    
    [self login];
}


- (void)login{
    AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
//    [app bindloginAcccount];//绑定手机id
    [app loginSuccess];
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"ddd");
    [self.nameField.textField resignFirstResponder];
    [self.passField.textField resignFirstResponder];
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
}

#pragma mark - UITextViewDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self autoTextField:textField];//自动展现
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
    [textField resignFirstResponder];
    return YES;
}


- (BOOL)textField:(UITextField *)textField
shouldChangeCharactersInRange:(NSRange)range
replacementString:(NSString *)string {
    //这里默认是最多输入12位
    if (textField==self.nameField.textField) {
        if (range.location >= 11)
            return NO; // return NO to not change text
    }
    return YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
