//
//  loginTextFiled.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "loginTextFiled.h"

@implementation loginTextFiled



-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
//        self.layer.borderWidth=.6;
//        self.layer.borderColor=RGB(200, 200, 200).CGColor;
    }
    return self;
}

- (void)addAllViews
{
    self.imageView=[[UIImageView alloc]initWithFrame:Frame(5, (self.frame.size.height-30)/2, 30, 30)];
    [self.imageView keep];
    [self addSubview:self.imageView];
    
    self.textField=[[UITextField alloc]initWithFrame:Frame(50, 5, self.frame.size.width-80, self.frame.size.height-10)];
    [self addSubview:self.textField];
    
    UILabel *lineLabel=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.height-1, self.frame.size.width, 1)];
    lineLabel.backgroundColor=RGB(200, 200, 200);
    [self addSubview:lineLabel];
    
}



@end
