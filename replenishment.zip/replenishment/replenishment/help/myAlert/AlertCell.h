//
//  AlertCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/25.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertCell : UITableViewCell

@property(nonatomic , strong)UILabel *serLabel;//序号
@property(nonatomic , strong)UILabel *shopLabel;//商品
@property(nonatomic , strong)UILabel *numberLabel;//数量
@end
