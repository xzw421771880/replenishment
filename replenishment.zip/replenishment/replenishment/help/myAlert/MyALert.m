//
//  MyALert.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "MyALert.h"

#import "AlertCell.h"

@implementation MyALert
{
    UITableView *detailTableView;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:Frame(WIDTH/2, HEIGHT/2, 0, 0)];
//    self=[super initWithFrame:frame];
    if (self) {
//        [self addAllViews];
        self.fr=frame;
        self.layer.cornerRadius =8;
        self.layer.masksToBounds =YES;
        
        self.backgroundColor=[UIColor whiteColor];
    }
    return self;
}

- (void)addAllViews
{
    
}


#pragma mark - 无效
-(void)wuXiao
{
    UILabel *title=[[UILabel alloc]initWithFrame:Frame(0, 0, self.frame.size.width, self.frame.size.height/3)];
    title.text=@"查询无效";
    title.textAlignment=YES;
    [self addSubview:title];
    
    UILabel *content=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.height/3, self.frame.size.width, self.frame.size.height/3)];
    content.text=@"请输入正确的快递单号";
    content.textAlignment=YES;
    [self addSubview:content];
    
    
    UILabel *close=[[UILabel alloc]initWithFrame:Frame((self.frame.size.width-60)/2, self.frame.size.height-40, 60, 30)];
    close.backgroundColor=HOMECOLOR;
    [close keep];
    close.layer.cornerRadius =5;
    close.layer.masksToBounds =YES;
    close.textColor=[UIColor whiteColor];
    close.text=@"关闭";
    close.textAlignment=YES;
    [self addSubview:close];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissMiss)];
    close.userInteractionEnabled=YES;
    [close addGestureRecognizer:tap];
    
}

#pragma mark - 详情
-(void)detail:(NSDictionary *)dic
{
    [self addTableView];
    
    
    UILabel *close=[[UILabel alloc]initWithFrame:Frame((self.frame.size.width-120)/2, self.frame.size.height-40, 120, 30)];
    close.backgroundColor=HOMECOLOR;
    [close keep];
    close.layer.cornerRadius =5;
    close.layer.masksToBounds =YES;
    close.textColor=[UIColor whiteColor];
    close.text=@"关闭";
    close.textAlignment=YES;
    [self addSubview:close];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissMiss)];
    close.userInteractionEnabled=YES;
    [close addGestureRecognizer:tap];
    
}

#pragma mark - 详情
-(void)queRen:(NSDictionary *)dic
{
    [self addTableView];
    self.type=@"确认";
    
    UILabel *quRen=[[UILabel alloc]initWithFrame:Frame((self.frame.size.width-240)/4, self.frame.size.height-40, 120, 30)];
    quRen.backgroundColor=HOMECOLOR;
    quRen.layer.cornerRadius =5;
    quRen.layer.masksToBounds =YES;
    quRen.textColor=[UIColor whiteColor];
    quRen.text=@"确认";
    quRen.textAlignment=YES;
    [self addSubview:quRen];
    
    UITapGestureRecognizer *qRtap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(quRenAction:)];
    quRen.userInteractionEnabled=YES;
    [quRen addGestureRecognizer:qRtap];
    
    
    UILabel *close=[[UILabel alloc]initWithFrame:Frame(self.frame.size.width/4*3-60, self.frame.size.height-40, 120, 30)];
    close.backgroundColor=[UIColor grayColor];
    close.layer.cornerRadius =5;
    close.layer.masksToBounds =YES;
    close.textColor=[UIColor whiteColor];
    close.text=@"取消";
    close.textAlignment=YES;
    [self addSubview:close];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissMiss)];
    close.userInteractionEnabled=YES;
    [close addGestureRecognizer:tap];
    
}

- (void)quRenAction:(UITapGestureRecognizer *)sender
{
    [self dissMiss];
}

#pragma mark - tableView
- (void)addTableView
{
    detailTableView =[[UITableView alloc]initWithFrame:Frame(0, 0, WIDTH, self.frame.size.height-40)];
    [self addSubview:detailTableView];
    detailTableView.delegate =self;
    detailTableView.dataSource =self;
//    [detailTableView quXian];
    [detailTableView registerClass:[AlertCell class] forCellReuseIdentifier:@"AlertCell"];
}



//弹出
-(void)Show:(UIView *)wind
{
    
    [wind addSubview:self.backGrandView];
    [wind addSubview:self];
    [UIView animateWithDuration:.5 animations:^{
        self.backGrandView.alpha=.5;
        self.frame=self.fr;
    }completion:^(BOOL finished) {
//        [self wuXiao];
    }];
    
}


//消失
-(void)dissMiss
{
    [UIView animateWithDuration:.5 animations:^{
        self.backGrandView.alpha=0;
        self.frame=Frame(WIDTH/2, HEIGHT/2, 0, 0);
    }completion:^(BOOL finished) {
        [self.backGrandView removeFromSuperview];
        [self removeFromSuperview];
    }];

}

//背景面板
-(UIView *)backGrandView
{
    
    if (_backGrandView==nil) {
        _backGrandView=[[UIView alloc]initWithFrame:Frame(0, 0, WIDTH, HEIGHT)];
        _backGrandView.backgroundColor=[UIColor blackColor];
        _backGrandView.alpha=0;
    }
    return _backGrandView;
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    return 15;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    AlertCell *cell =[tableView dequeueReusableCellWithIdentifier:@"AlertCell" forIndexPath:indexPath];

    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *title=[[UIView alloc]initWithFrame:Frame(0, 0, WIDTH, 70)];
    title.backgroundColor=[UIColor whiteColor];
    UILabel *titleLabel=[[UILabel alloc]initWithFrame:Frame(10, 5, WIDTH-20, 30)];
    titleLabel.textAlignment=YES;
    if ([self.type isEqualToString:@"确认"]) {
        titleLabel.text=@"取货清单确认         共10箱";
    }else{
        titleLabel.text=@"装箱单号   1001010101010    总量（包）  20";
    }
    [title addSubview:titleLabel];
    
    
    //    UIView *v=[[UIView alloc]init];
    //    v.backgroundColor=[UIColor greenColor];
    return title;
}

@end
