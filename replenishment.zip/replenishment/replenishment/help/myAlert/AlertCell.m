//
//  AlertCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/25.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "AlertCell.h"

@implementation AlertCell


#pragma mark - 新建cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addAllViews];
        //        self.backgroundColor=[UIColor redColor];
        [self noOne];
    }
    return self;
}

#pragma mark - 给cell添加控件
-(void)addAllViews
{
    self.serLabel=[[UILabel alloc]initWithFrame:Frame(0, 0, WIDTH/3, 40)];
    self.serLabel.text=@"01";
    self.serLabel.textAlignment=YES;
    [self addSubview:self.serLabel];
    
    self.shopLabel=[[UILabel alloc]initWithFrame:Frame(WIDTH/3, 0, WIDTH/3, 40)];
    self.shopLabel.text=@"天府龙茅";
    self.shopLabel.textAlignment=YES;
    [self addSubview:self.shopLabel];
    
    self.numberLabel=[[UILabel alloc]initWithFrame:Frame(WIDTH/3*2, 0, WIDTH/3, 40)];
    self.numberLabel.text=@"11";
    self.numberLabel.textAlignment=YES;
    [self addSubview:self.numberLabel];
    
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
