//
//  MyPicker.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MypickerDelegate <NSObject>

- (void)sendDate:(NSString *)date;

@end

@interface MyPicker : UIView

@property (nonatomic,assign)id<MypickerDelegate>deleagte;

@property(nonatomic,strong)UIView *backGrandView;

@property(nonatomic,assign)CGRect fr;

@property(nonatomic,strong)NSString *myDate;



-(void)Show;

@end
