//
//  MyALert.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyALert : UIView<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UIView *backGrandView;

@property(nonatomic,assign)CGRect fr;

@property(nonatomic,strong)NSString *type;


//无效
-(void)wuXiao;


//详情
-(void)detail:(NSDictionary *)dic;

-(void)queRen:(NSDictionary *)dic;

-(void)Show:(UIView *)wind;

-(void)dissMiss;
@end
