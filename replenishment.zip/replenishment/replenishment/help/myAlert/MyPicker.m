//
//  MyPicker.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "MyPicker.h"
#import "AppDelegate.h"
#import "xzw_Date.h"

@implementation MyPicker

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:Frame(frame.origin.x, HEIGHT, frame.size.width, frame.size.height)];
//        self=[super initWithFrame:frame];
    if (self) {
        
        self.myDate=[xzw_Date getDate:[NSDate date]];
        [self addAllViews];
        self.fr=frame;
        self.layer.cornerRadius =8;
        self.layer.masksToBounds =YES;
        
        self.backgroundColor=[UIColor whiteColor];
        
        
    }
    return self;
}

-(void)addAllViews
{
    UILabel *que=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.height-50, WIDTH, 50)];
    
    que.textColor=[UIColor whiteColor];
    que.backgroundColor=HOMECOLOR;
    que.textAlignment=YES;
    que.text=@"确认";
    [self addSubview:que];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(queRen)];
    que.userInteractionEnabled=YES;
    [que addGestureRecognizer:tap];
    
    [self addPicker];
}


- (void)addPicker
{
        UIDatePicker * startPicker =[[UIDatePicker alloc]initWithFrame:Frame(0, 0, WIDTH, 150)];
        [startPicker setDatePickerMode:UIDatePickerModeDate];//年月日
        startPicker.tintColor=HOMECOLOR;
        //监听datepicker值的改变
    
        [startPicker addTarget:self action:@selector(dateChange:)forControlEvents:UIControlEventValueChanged];
        [self addSubview:startPicker];
}

- (void)dateChange:(UIDatePicker *)date

{
    
    NSLog(@"%@", date.date);
    self.myDate=[xzw_Date getDate:date.date];
    
    NSLog(@"date===%@",self.myDate);
    
}

#pragma mark - 确认

-(void)queRen
{
    
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendDate:)]) {
        [_deleagte sendDate:self.myDate];
    }
    
    [self dissMiss];
}

-(void)Show
{
     AppDelegate *app=(AppDelegate *)[UIApplication sharedApplication].delegate;
    [app.window addSubview:self.backGrandView];
    [app.window addSubview:self];
    [UIView animateWithDuration:.3 animations:^{
        self.backGrandView.alpha=.5;
        self.frame=self.fr;
    }completion:^(BOOL finished) {
        //        [self wuXiao];
    }];
    
}


//消失
-(void)dissMiss
{
    [UIView animateWithDuration:.3 animations:^{
        self.backGrandView.alpha=0;
        self.frame=Frame(self.frame.origin.x, HEIGHT, self.frame.size.width, self.frame.size.height);
    }completion:^(BOOL finished) {
        [self.backGrandView removeFromSuperview];
        [self removeFromSuperview];
    }];
    
}

//背景面板
-(UIView *)backGrandView
{
    
    if (_backGrandView==nil) {
        _backGrandView=[[UIView alloc]initWithFrame:Frame(0, 0, WIDTH, HEIGHT)];
        _backGrandView.backgroundColor=[UIColor blackColor];
        _backGrandView.alpha=0;
        
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dissMiss)];
        _backGrandView.userInteractionEnabled=YES;
        [_backGrandView addGestureRecognizer:tap];
    }
    return _backGrandView;
}

@end
