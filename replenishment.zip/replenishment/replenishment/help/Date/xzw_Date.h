//
//  xzw_Date.h
//  catTaxi
//
//  Created by mc on 2018/2/8.
//  Copyright © 2018年 mc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface xzw_Date : NSObject
+(NSString *)getNowTimeTimestamp3;

+(NSString *)getDate:(NSDate *)date;
@end
