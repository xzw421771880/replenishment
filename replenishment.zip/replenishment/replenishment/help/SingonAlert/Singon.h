//
//  Singon.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Singon : NSObject

@property(nonatomic,strong)UIView *backGrandView;

//创建一个唯一对象
+(Singon *)deafauting;
@end
