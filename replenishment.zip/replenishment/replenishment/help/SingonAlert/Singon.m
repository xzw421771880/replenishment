//
//  Singon.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "Singon.h"

@implementation Singon

//创建一个唯一对象
+ (Singon *)deafauting
{
    static Singon * singon = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singon = [[Singon alloc]init];
    });
    return singon;
}

-(UIView *)backGrandView
{
    
    if (_backGrandView==nil) {
        _backGrandView=[[UIView alloc]initWithFrame:Frame(0, 0, WIDTH, HEIGHT)];
        _backGrandView.backgroundColor=[UIColor blackColor];
//        _backGrandView.hidden=YES;
        _backGrandView.alpha=.4;
    }
    return _backGrandView;
}



@end
