//
//  XZW_textField.m
//  catTaxi
//
//  Created by mc on 2017/12/16.
//  Copyright © 2017年 mc. All rights reserved.
//

#import "XZW_textField.h"

@implementation XZW_textField

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
        self.layer.borderWidth=.6;
        self.layer.borderColor=RGB(200, 200, 200).CGColor;
    }
    return self;
}

- (void)addAllViews
{
    self.imageView=[[UIImageView alloc]initWithFrame:Frame(5, (self.frame.size.height-20)/2, 20, 20)];
    [self addSubview:self.imageView];
    
    self.textField=[[UITextField alloc]initWithFrame:Frame(35, 5, self.frame.size.width-40, self.frame.size.height-10)];
    [self addSubview:self.textField];
    
}

@end
