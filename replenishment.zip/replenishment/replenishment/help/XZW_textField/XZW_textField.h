//
//  XZW_textField.h
//  catTaxi
//
//  Created by mc on 2017/12/16.
//  Copyright © 2017年 mc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZW_textField : UIView

@property(nonatomic, strong)UIImageView *imageView;
@property(nonatomic, strong)UITextField *textField;
@end
