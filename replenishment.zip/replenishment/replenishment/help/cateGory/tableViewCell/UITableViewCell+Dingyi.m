//
//  UITableViewCell+Dingyi.m
//  HuaXin
//
//  Created by dingyi on 16/2/24.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import "UITableViewCell+Dingyi.h"

@implementation UITableViewCell (Dingyi)
//选择类型
-(void)noOne
{
    self.selectionStyle =UITableViewCellSelectionStyleNone;
}

@end
