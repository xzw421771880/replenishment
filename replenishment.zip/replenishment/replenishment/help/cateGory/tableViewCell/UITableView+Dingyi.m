//
//  UITableView+Dingyi.m
//  HuaXin
//
//  Created by dingyi on 16/2/24.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import "UITableView+Dingyi.h"

@implementation UITableView (Dingyi)
//取出下面的线
-(void)quXian
{
//    self.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.separatorStyle =NO;
}
@end
