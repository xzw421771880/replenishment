//
//  UIViewController+HuaZhi.m
//  furongPassenger
//
//  Created by mc on 2017/12/2.
//  Copyright © 2017年 Baidu. All rights reserved.
//

#import "UIViewController+HuaZhi.h"



#import "AppDelegate.h"


static NSString * const FORM_FLE_INPUT = @"file";



@implementation UIViewController (HuaZhi)
-(void)alertWith:(NSString *)str
{
    UIAlertView * alert= [[UIAlertView alloc] initWithTitle:str message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
    [alert show];
}


-(void)actionSheet
{
    UIActionSheet *myActionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从手机选择",@"拍照", nil];
    myActionSheet.delegate = self;
    myActionSheet.tag = 16;
    [myActionSheet showInView:self.view];
}

//选择上传方式
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (actionSheet.tag == 16){
        __weak id wself = self;
        
        if (buttonIndex == 0) {
            UIImagePickerControllerSourceType   sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            UIImagePickerController             *picker = [[UIImagePickerController alloc] init];
            picker.delegate = wself;
            picker.allowsEditing=YES;
            picker.sourceType = sourceType;
            [self presentViewController:picker animated:YES completion:^{
                
            }];
        }else if (buttonIndex == 1){
            UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
            
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            }
            UIImagePickerController *picker = [[UIImagePickerController alloc] init];
            picker.delegate = wself;
            picker.sourceType = sourceType;
            picker.allowsEditing=YES;
            [self presentViewController:picker animated:YES completion:^{
            }];
        }
    }
}


#pragma mark - 输入框自动排列
-(void)autoTextField:(UITextField *)textField
{

    //初始值
    CGFloat height=textField.frame.size.height;
    CGFloat orgin_y=textField.frame.origin.y;
    
    UIView *view=textField;
    
    //更新orgin_y
    while (view.superview!=self.view) {
        view=view.superview;//获取s
        orgin_y +=view.frame.origin.y;
    }
   
    
    //如果遮盖住输入框改变frame
    if(height+orgin_y>HEIGHT-260) {//260是键盘覆盖高度
        
        //动画适应键盘
        [UIView animateWithDuration:0.3 animations:^{
             self.view.frame=Frame(0, HEIGHT-260-height-orgin_y, WIDTH, 260+height+orgin_y);
        }];
    }
}




#pragma mark - 获取本地Driver
-(NSMutableDictionary *)getUser
{
    NSMutableDictionary *dic=[[NSUserDefaults standardUserDefaults] objectForKey:@"user"];
    return dic;
}





@end
