//
//  UILabel+HuaZhi.m
//  selectDemo
//
//  Created by mc on 2017/11/25.
//  Copyright © 2017年 mc. All rights reserved.
//

#import "UILabel+HuaZhi.h"

@implementation UILabel (HuaZhi)

//紧跟label
-(void)followLabel:(UILabel *)label
{
    CGSize sizexy=[self sizeWithString:self.text font:self.font];
    self.frame=Frame(label.frame.origin.x+label.frame.size.width+8, self.frame.origin.y, sizexy.width, self.frame.size.height);
}

//右对齐
-(void)rightWithJuli:(float)a
{
    CGSize labelsize =[self sizeWithString:self.text font:self.font];
    self.frame =Frame(WIDTH -labelsize.width -a, self.frame.origin.y, labelsize.width, self.frame.size.height);
}

//自动宽度
- (void)aotuWidth
{
    CGSize sizexy=[self sizeWithString:self.text font:self.font];
    self.frame=Frame(self.frame.origin.x, self.frame.origin.y, sizexy.width, self.frame.size.height);
}

//求出label的长度
- (CGSize)sizeWithString:(NSString *)string font:(UIFont *)font
{
    CGRect rect = [string boundingRectWithSize:CGSizeMake(320, 8000)//限制最大的宽度和高度
                                       options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading  |NSStringDrawingUsesLineFragmentOrigin//采用换行模式
                                    attributes:@{NSFontAttributeName: font}//传人的字体字典
                                       context:nil];
    return rect.size;
}

@end
