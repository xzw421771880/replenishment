//
//  UIView+ZhongWang.m
//  catTaxi
//
//  Created by mc on 2017/12/7.
//  Copyright © 2017年 mc. All rights reserved.
//

#import "UIView+ZhongWang.h"

@implementation UIView (ZhongWang)

#pragma mark - 变圆
- (void)circle {
    self.layer.cornerRadius =self.frame.size.height/2;
    self.layer.masksToBounds =YES;
}
- (void)circle:(CGFloat )count {
    self.layer.cornerRadius =count;
    self.layer.masksToBounds =YES;
}



#pragma mark - 保持
- (void)keep{
    self.contentMode =UIViewContentModeScaleAspectFit;
}

#pragma mark - 右边
-(void)addRightImage
{
    UIImageView *nextImage=[[UIImageView alloc]initWithFrame:Frame(WIDTH-35, (self.frame.size.height-20)/2, 20, 20)];
    [nextImage keep];
    nextImage.image=[UIImage imageNamed:@"white_right_ico"];
    //    nextImage.backgroundColor=[UIColor redColor];
    [self addSubview:nextImage];
}

//扫一扫动画
-(void)donghua
{
    CAKeyframeAnimation *keyAn = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [keyAn setDuration:2];
    NSArray *array = [[NSArray alloc] initWithObjects:
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*0)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.1)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.2)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.3)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.4)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.5)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.6)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.7)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.8)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU*.9)],
                      [NSValue valueWithCGPoint:CGPointMake(self.center.x, self.center.y+CHANGDU)],
                      nil];
    [keyAn setValues:array];
    NSArray *times = [[NSArray alloc] initWithObjects:
                      [NSNumber numberWithFloat:0],
                      [NSNumber numberWithFloat:0.1f],
                      [NSNumber numberWithFloat:0.2f],
                      [NSNumber numberWithFloat:0.3f],
                      [NSNumber numberWithFloat:0.4f],
                      [NSNumber numberWithFloat:0.5f],
                      [NSNumber numberWithFloat:0.6f],
                      [NSNumber numberWithFloat:0.7f],
                      [NSNumber numberWithFloat:0.8f],
                      [NSNumber numberWithFloat:0.9f],
                      [NSNumber numberWithFloat:1.0f],
                      nil];
    [keyAn setKeyTimes:times];
    [self.layer addAnimation:keyAn forKey:@"TextAnim"];
}

-(void)addFooterLine
{
    UILabel *lineLabel=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.height-1, WIDTH, 1)];
    lineLabel.backgroundColor=RGB(235, 235, 235);
    [self addSubview:lineLabel];
}

-(void)addFooterLine:(CGFloat)height
{
    UILabel *lineLabel=[[UILabel alloc]initWithFrame:Frame(0, height-1, WIDTH, 1)];
    lineLabel.backgroundColor=RGB(235, 235, 235);
    [self addSubview:lineLabel];
}

-(void)addselfFooterLine
{
    UILabel *lineLabel=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.height-1, self.frame.size.width, 1)];
    lineLabel.backgroundColor=RGB(235, 235, 235);
    [self addSubview:lineLabel];
}



@end
