//
//  UIView+ZhongWang.h
//  catTaxi
//
//  Created by mc on 2017/12/7.
//  Copyright © 2017年 mc. All rights reserved.
//

#import <UIKit/UIKit.h>

#define CHANGDU  HEIGHT*.5

@interface UIView (ZhongWang)

//
- (void)circle;

- (void)circle:(CGFloat )count;

//
- (void)keep;

//
-(void)addRightImage;


-(void)donghua;


#pragma mark - 底部线条
-(void)addFooterLine;

-(void)addFooterLine:(CGFloat)height;

-(void)addselfFooterLine;
@end
