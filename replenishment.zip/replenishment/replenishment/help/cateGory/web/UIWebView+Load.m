//
//  UIWebView+Load.m
//  HuaXin
//
//  Created by dingyi on 16/2/24.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import "UIWebView+Load.h"


@implementation UIWebView (Load)

//加载数据
-(void)loadViewWithStr:(NSString *)str
{
    NSURL *url = [NSURL URLWithString:str];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [self loadRequest:urlRequest];
}


//获取webView 页面的url
-(NSString *)url
{
    NSString *url =[self stringByEvaluatingJavaScriptFromString:@"document.location.href"];
    return url;
}


//获取webView 页面的title
-(NSString *)title
{
    NSString *title =[self stringByEvaluatingJavaScriptFromString:@"document.title"];
    return title;
}


@end
