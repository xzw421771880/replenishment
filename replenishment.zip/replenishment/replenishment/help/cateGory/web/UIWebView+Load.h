//
//  UIWebView+Load.h
//  HuaXin
//
//  Created by dingyi on 16/2/24.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (Load)
-(void)loadViewWithStr:(NSString *)str;

//获取webView 页面的url
-(NSString *)url;

//获取webView 页面的title
-(NSString *)title;
@end
