//
//  UIViewController+HuaZhi.h
//  furongPassenger
//
//  Created by mc on 2017/12/2.
//  Copyright © 2017年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (HuaZhi)

-(void)alertWith:(NSString *)str;
-(void)actionSheet;

#pragma mark - 输入框自动排列
-(void)autoTextField:(UITextField *)textField;

#pragma mark - 获取参数加密key
-(NSString *)getMd5Key;

#pragma mark - 获取本地用户
-(NSMutableDictionary *)getUser;

- (UIImage *)thumbnailWithImageWithoutScale:(UIImage *)image size:(CGSize)asize;

#pragma mark - 转换成字符串
- (NSString *)saveImage:(UIImage *)image;

#pragma mark - 获取请求
- (NSMutableURLRequest *)postRequestWithURL: (NSString *)url  // IN
                                        postParems: (NSMutableDictionary *)postParems // IN
                                       picFilePath: (NSString *)picFilePath  // IN
                                       picFileName: (NSString *)picFileName;
@end
