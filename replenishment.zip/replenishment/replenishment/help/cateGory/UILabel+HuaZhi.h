//
//  UILabel+HuaZhi.h
//  selectDemo
//
//  Created by mc on 2017/11/25.
//  Copyright © 2017年 mc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (HuaZhi)

//自动宽度
- (void)aotuWidth;


//紧跟label
-(void)followLabel:(UILabel *)label;


//右对齐
-(void)rightWithJuli:(float)a;
@end
