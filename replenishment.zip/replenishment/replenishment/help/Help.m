//
//  Help.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "Help.h"

@implementation Help


//判断手机号码
+(BOOL)CheckPhoneNumInput:(NSString *)_text{
    
    //NSString *Regex =@"(13[0-9]|14[57]|15[012356789]|18[02356789])\\d{8}";
    NSString *Regex =@"^1[\\d]{10}$";
    
    NSPredicate *mobileTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", Regex];
    
    return [mobileTest evaluateWithObject:_text];
    
}


@end
