//
//  TabBarViewController.m
//  HuaXInApp
//
//  Created by 戎博 on 15/11/26.
//  Copyright © 2015年 昆博. All rights reserved.
//

#import "TabBarViewController.h"

//补货+我的+水站+服务商+负责人

#import "ReplenishViewController.h"
#import "MineViewController.h"
#import "WaterViewController.h"
#import "ServicepViewController.h"
#import "PrincipalViewController.h"


//#import "Simplify.h"

@interface TabBarViewController ()
{
//    NaviationBar *nav;
}

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configBarViewController];

}


- (void)configBarViewController
{
    //controllers ＋标题 ＋图片
    NSArray * controllerNames = @[@"ReplenishViewController", @"MineViewController", @"WaterViewController", @"ServicepViewController",@"PrincipalViewController"];
    NSArray * titles = @[@"补货", @"我的", @"水站", @"服务商",@"负责人"];

    NSArray * seleteimages =@[@"buhuo",@"geren_zhongxin",@"ic_huizong",@"ic_biaoqian_qygly",@"geren_zhongxin"];
    NSMutableArray * viewControllers = [@[] mutableCopy];
    for (int i = 0; i < titles.count; i++) {
        UIViewController * Vc = [[NSClassFromString(controllerNames[i]) alloc] init];
        Vc.navigationItem.title =titles[i];
        UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:Vc];
       
        nav.navigationBar.barTintColor = HOMECOLOR;

        nav.tabBarItem.title =titles[i];
//        nav.tabBarItem.selectedImage =[UIImage imageNamed:seleteimages[i]];
        nav.tabBarItem.image = [[UIImage imageNamed:seleteimages[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        nav.tabBarItem.selectedImage = [[UIImage imageNamed:[NSString stringWithFormat:@"%@_xuan",seleteimages[i]] ] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        
//        self.tabBar.tintColor =[UIColor colorWithRed:80 green:170 blue:155 alpha:1];
        [nav.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:HOMECOLOR} forState:UIControlStateSelected];

//        nav.tabBarItem.image =[UIImage imageNamed:images[i]];
        [viewControllers addObject:nav];
    }
    self.viewControllers = viewControllers;
    

}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
