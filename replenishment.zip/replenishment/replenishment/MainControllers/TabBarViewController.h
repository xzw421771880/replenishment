//
//  TabBarViewController.h
//  HuaXInApp
//
//  Created by 戎博 on 15/11/26.
//  Copyright © 2015年 昆博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarViewController : UITabBarController

@property (nonatomic, assign)NSInteger index;
@end
