//
//  ReplenishViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/21.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "ReplenishViewController.h"

#import "bhTitle.h"

#import "SaoyisaoViewController.h"//扫一扫
#import "EweimaViewController.h"//二维码

#import "Que_renTableViewCell.h"//确认取货
#import "Bu_detailTableViewCell.h"//补货详情

#import "TeaView.h"//header收货种类



@interface ReplenishViewController ()<UIScrollViewDelegate,bhTitleDelegate,UITableViewDelegate,UITableViewDataSource,TeaViewDelegate,Que_renTableViewCellDelegate,detailCellDelegate>

{
    UIScrollView *scroll;
    
    MyALert *alert;//弹窗
    
    bhTitle *bhtitle;//补货标题
    
    UITableView *atableView;//补货列表
    UITableView *btableView;
    
    
    NSArray *teaAry;
    
    NSArray *danAry;
    
    NSMutableArray *xiaLaTitleAry;//控制title下拉
    NSMutableArray *xiaLaDanAry;//控制单下拉
    
    NSMutableDictionary *userDic;
}

@end

@implementation ReplenishViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    // Do any additional setup after loading the view.
    
//    [self addSerach];
    
    userDic =[self getUser];
    
    teaAry=@[@"茶叶",@"茶具"];
    xiaLaTitleAry=@[@"0",@"0"].mutableCopy;
    danAry=@[@[@"快递单号100001",@"快递单号100002"],@[@"快递单号100003",@"快递单号100004",@"快递单号100005"]];
    xiaLaDanAry=@[@[@"0",@"0"],@[@"0",@"0",@"0"]].mutableCopy;
//    NSArray *teaAry=@[@"",@""];
   
    [self addLeftImage];
    
    [self addRightImage];
    [self addBhTitle];
    
    [self addScroll];
}

#pragma mark - 添加左上角图片
- (void)addLeftImage
{
    UIImageView *img = [[UIImageView alloc] init];
    img.image = [UIImage imageNamed:@"er_wei_ma"];
    img.frame = Frame(0.0, 0.0, 25.0, 25);
    [img keep];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:img];
    
    //    [img circle];
    
    UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(leftAction:)];
    [img addGestureRecognizer:tap];
}

-(void)leftAction:(UITapGestureRecognizer *)sender
{

//    alert=[[MyALert alloc]initWithFrame:Frame(10, (HEIGHT-120)/2, WIDTH-20, 120)];
//    [alert Show:self.view.window];
//    [alert wuXiao];
    
    EweimaViewController *vc=[[EweimaViewController alloc]init];
    self.hidesBottomBarWhenPushed =YES;
    vc.title=@"生成二维码";
    [self.navigationController pushViewController:vc animated:YES];
    self.hidesBottomBarWhenPushed =NO;
}

-(void)add:(UIView *)vi
{
    
}

#pragma mark - 添加右上角图片
- (void)addRightImage
{
    UIImageView *img = [[UIImageView alloc] init];
    img.image = [UIImage imageNamed:@"pai_zhao"];
    [img keep];
    img.frame = Frame(0.0, 0.0, 25.0, 25);
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:img];
    
    //    [img circle];
    
    UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(RightAction:)];
    [img addGestureRecognizer:tap];
}

-(void)RightAction:(UITapGestureRecognizer *)sender
{
    SaoyisaoViewController *vc=[[SaoyisaoViewController alloc]init];
    self.hidesBottomBarWhenPushed =YES;
    vc.title=@"扫描二维码";
    [self.navigationController pushViewController:vc animated:YES];
    self.hidesBottomBarWhenPushed =NO;
}

-(void)addSerach
{
    self.busearch=[[buSerach alloc]initWithFrame:Frame(10, 80, WIDTH-80, 35)];
    [self.view addSubview:self.busearch];
    [self searchBut];
}

#pragma mark - 搜索
- (void)searchBut
{
    UIButton *but =[UIButton buttonWithType:UIButtonTypeCustom];
    but.frame=Frame(WIDTH-70, 80, 60, 35);
    [but setTitle:@"搜索" forState:UIControlStateNormal];
//    but.backgroundColor=HOMECOLOR;
//    but.titleLabel.textColor=[UIColor grayColor];
    [but setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [but addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:but];
    
}

- (void)search
{
    
}

#pragma mark - 补货标题
-(void)addBhTitle
{
    bhtitle=[[bhTitle alloc]initWithFrame:Frame(10, 80, WIDTH-20, (WIDTH-20)/4)];
    bhtitle.deleagte=self;
    [self.view addSubview:bhtitle];
}


#pragma mark - scroll
-(void)addScroll
{
    scroll =[[UIScrollView alloc]initWithFrame:Frame(0, bhtitle.frame.size.height+bhtitle.frame.origin.y, WIDTH, HEIGHT -bhtitle.frame.size.height-bhtitle.frame.origin.y-40)];
    scroll.contentSize =CGSizeMake(WIDTH*4, 0);
    scroll.delegate =self;
    scroll.pagingEnabled =YES;
    [self.view addSubview:scroll];
    [self addaTableView];
}



#pragma mark - 添加待取货
- (void)addaTableView
{
    atableView =[[UITableView alloc]initWithFrame:Frame(0, 0, WIDTH, scroll.frame.size.height)];
    [scroll addSubview:atableView];
    atableView.delegate =self;
    atableView.dataSource =self;
    [atableView quXian];
    [atableView registerClass:[Que_renTableViewCell class] forCellReuseIdentifier:@"Que_renTableViewCell"];
    [atableView registerClass:[Bu_detailTableViewCell class] forCellReuseIdentifier:@"Bu_detailTableViewCell"];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return teaAry.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
//    if (section == 0) {
//        return 1;
//    }else {
////        return self.dataSourceArray.count;
//    }
    //判断是否下拉
    if ([xiaLaTitleAry[section] isEqualToString:@"0"]) {
        return 0;
    }else{
        NSArray *ary=danAry[section];
        return ary.count;
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([userDic[@"pw"] isEqualToString:@"2"]) {//有代理商
        Que_renTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"Que_renTableViewCell" forIndexPath:indexPath];
        cell.deleagte=self;
        cell.index=indexPath;
        
        if ([xiaLaDanAry[indexPath.section][indexPath.row] isEqualToString:@"0"]) {
            cell.selete=NO;
        }else{
            cell.selete=YES;
        }
        cell.detaiAry=@[@"",@"",@""];
        [cell changeStatus];
        //    cell.dataDic =aDataArr[indexPath.row];
        return cell;
    }else{//无代理商
        Bu_detailTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"Bu_detailTableViewCell" forIndexPath:indexPath];
        cell.deleagte=self;
        cell.index=indexPath;
        
        
        return cell;
    }
    
    
//    if (indexPath.section == 0) {
//        AuctionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cells" forIndexPath:indexPath];
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
//        cell.auction = self.auct;
//        return cell;
//    }else {
//        AuctionDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
//        AuctionDetail *detail = self.dataSourceArray[indexPath.row];
//        cell.auctionDetail = detail;
//        return cell;
//    }
//    return nil;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([userDic[@"pw"] isEqualToString:@"2"]) {//有代理商
        NSString *select=xiaLaDanAry[indexPath.section][indexPath.row];
        if ([select isEqualToString:@"0"]) {
            return 40;
        }else{
            return 40+3*60;
        }
    }else{
        return 60;//无代理商
    }
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 60;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    TeaView *v=[[TeaView alloc]initWithFrame:Frame(0, 0, WIDTH, 60)];
    v.deleagte=self;
    if ([xiaLaTitleAry[section] isEqualToString:@"0"]) {
        v.selete=NO;
    }else{
        v.selete=YES;
    }
    [v changeStatus];
    
    v.tag=section+1;
//    UIView *v=[[UIView alloc]init];
//    v.backgroundColor=[UIColor greenColor];
    return v;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
}


#pragma mark - TeaViewDelegate

- (void)sendTeaView:(UIView *)view
{
//    TeaView *tea=(TeaView *)view;
    if ([xiaLaTitleAry[view.tag-1] isEqualToString:@"0"]) {
        [xiaLaTitleAry replaceObjectAtIndex:view.tag-1 withObject:@"1"];
    }else{
        [xiaLaTitleAry replaceObjectAtIndex:view.tag-1 withObject:@"0"];
    }
    [atableView reloadData];
   
}

#pragma mark - Que_renTableViewCellDelegate

//拉伸功能
-(void)sendLaShenNSIndex:(NSIndexPath *)index
{
    
    NSArray *Ary= xiaLaDanAry[index.section];
    NSMutableArray *mAry=Ary.mutableCopy;
    NSString *select=xiaLaDanAry[index.section][index.row];
    if ([select isEqualToString:@"0"]) {
        [mAry replaceObjectAtIndex:index.row withObject:@"1"];
    }else{
        [mAry replaceObjectAtIndex:index.row withObject:@"0"];
    }
    Ary=mAry.copy;
    [xiaLaDanAry replaceObjectAtIndex:index.section withObject:Ary];
   
    [atableView reloadData];
}


//确认
-(void)sendQueRenNSIndex:(NSIndexPath *)index
{
    alert=[[MyALert alloc]initWithFrame:Frame(10, (HEIGHT-400)/2, WIDTH-20, 400)];
    [alert Show:self.view.window];
    [alert queRen:nil];
}

//查看详情
-(void)sendNSIndex:(NSIndexPath *)index andDetailLabel:(UIView *)detailLabel
{
    alert=[[MyALert alloc]initWithFrame:Frame(10, (HEIGHT-400)/2, WIDTH-20, 400)];
    [alert Show:self.view.window];
    [alert detail:nil];
}


#pragma mark - detailCellDelegate

-(void)sendDetailNSIndex:(NSIndexPath *)index
{
    alert=[[MyALert alloc]initWithFrame:Frame(10, (HEIGHT-400)/2, WIDTH-20, 400)];
    [alert Show:self.view.window];
    [alert detail:nil];
}

#pragma mark ----scrollview代理方法-----
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    if (scrollView ==scroll) {
        CGFloat Xwidth = scrollView.contentOffset.x;
        NSInteger index = (int)Xwidth / WIDTH;
        [bhtitle backgroundChange:(int)index];
        //        UIButton *btn = [xzw_select viewWithTag:10 + index];
        //        [vi  butClicked:btn];//调用方法 实现点击效果
    }
}

- (void)sendButIndex:(NSInteger)indexNum
{
    scroll.contentOffset =CGPointMake(indexNum *WIDTH, 0);
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"ddd");
    [self.busearch.textField resignFirstResponder];
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
}

#pragma mark - UITextViewDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self autoTextField:textField];//自动展现
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
    [textField resignFirstResponder];
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
