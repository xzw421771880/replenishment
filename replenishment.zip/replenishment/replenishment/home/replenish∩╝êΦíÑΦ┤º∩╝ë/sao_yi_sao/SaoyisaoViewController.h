//
//  SaoyisaoViewController.h
//  HuaXin
//
//  Created by dingyi on 16/2/18.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import "BaseViewController.h"

@interface SaoyisaoViewController : BaseViewController

@end
