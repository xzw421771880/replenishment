//
//  WebbViewController.h
//  HuaXin
//
//  Created by hu on 16/4/6.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebbViewController : UIViewController

@property (nonatomic,strong) NSString *URL;

@end
