//
//  SaoyisaoViewController.m
//  HuaXin
//
//  Created by dingyi on 16/2/18.
//  Copyright © 2016年 昆博. All rights reserved.
//

#import "SaoyisaoViewController.h"
#import <QuickLook/QuickLook.h>
#import <AVFoundation/AVFoundation.h>

#import "WebbViewController.h"

@interface SaoyisaoViewController ()<AVCaptureMetadataOutputObjectsDelegate>
{
    //扫描
    AVCaptureDevice * device;
    UIView * _boxView;
    UIImageView *iView;
    
    UILabel *lamplight;
    
   
}
@property (strong, nonatomic) CALayer *scanLayer;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *videoPreviewLayer;
@property (nonatomic, retain) AVCaptureSession * session;

@end

@implementation SaoyisaoViewController

- (void)viewWillAppear:(BOOL)animated
{
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        // iOS 7
        [self prefersStatusBarHidden];
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    }
    [_session startRunning];
}
- (BOOL)prefersStatusBarHidden
{
    return NO;//隐藏为YES，显示为NO
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =[UIColor whiteColor];
    
//    [self addLeftImage];
    [self addRightImage];
    [self startSaomiao];
}

#pragma mark - 添加左上角图片


-(void)leftAction:(UITapGestureRecognizer *)sender
{
    [self.session stopRunning];
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - 添加右上角图片
- (void)addRightImage
{
    lamplight= [[UILabel alloc] init];
//    L=.image = [UIImage imageNamed:@"pai_zhao"];
//    [img keep];
    lamplight.text=@"开灯";
    lamplight.frame = Frame(0.0, 0.0, 35.0, 25);
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:lamplight];
    
    //    [img circle];
    
    UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(RightAction:)];
    lamplight.userInteractionEnabled=YES;
    [lamplight addGestureRecognizer:tap];
}


#pragma mark - 开启灯光
-(void)RightAction:(UITapGestureRecognizer *)sender
{
    if (sender.view.tag ==2) {
        sender.view.tag =1;
        lamplight.text=@"开灯";
        [self.session stopRunning];
    }else
    {
        sender.view.tag =2;
        lamplight.text=@"关灯";
        [self.session beginConfiguration];
        [device lockForConfiguration:nil];
        [device setTorchMode:AVCaptureTorchModeOn];
        [device setFlashMode:AVCaptureFlashModeOn];
        [device unlockForConfiguration];
        [self.session commitConfiguration];
        [self.session startRunning];
        
    }
}

//左边按钮
-(void)leftButtonAction
{
    [self.navigationController popViewControllerAnimated:YES];
}





#pragma mark - 开始扫描
-(void)startSaomiao
{
    //获取摄像设备
    device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    //    AVCaptureFlashMode * model = AVCaptureFlashModeAuto;
    
    
    AVCaptureDeviceInput * input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    if (!input) return;
    //创建输出流
    AVCaptureMetadataOutput * output = [[AVCaptureMetadataOutput alloc]init];
    //设置代理 在主线程里刷新
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    //设置有效扫描区域
    //    CGRect scanCrop=self.view.frame;
    //    output.rectOfInterest = scanCrop;
    [output setRectOfInterest:CGRectMake(0.2f, 0.2f, 0.8f, 0.8f)];
    //初始化链接对象
    _session = [[AVCaptureSession alloc]init];
    //高质量采集率
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    
    [_session addInput:input];
    [_session addOutput:output];
    //设置扫码支持的编码格式(如下设置条形码和二维码兼容)
    output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode128Code,];
    
    AVCaptureVideoPreviewLayer * layer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    layer.videoGravity=AVLayerVideoGravityResizeAspectFill;
    layer.frame=self.view.layer.bounds;
    [self.view.layer insertSublayer:layer atIndex:0];
    //    layer.backgroundColor = [UIColor grayColor].CGColor;
    //    self.view.backgroundColor = [UIColor grayColor];
    //    UIView * mengBan = [[UIView alloc] init]
    
    
    _scanLayer = [[CALayer alloc] init];
    _scanLayer.frame = CGRectMake(0, 0, _boxView.bounds.size.width, 1);
    _scanLayer.backgroundColor = [UIColor brownColor].CGColor;
    //开始捕获
    [_session startRunning];
    
    
    _boxView = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH * 0.1f, HEIGHT * 0.25f, WIDTH - WIDTH * 0.2f, HEIGHT - HEIGHT * 0.5f)];
     iView=[[UIImageView alloc]initWithFrame:Frame(0, 0, _boxView.frame.size.width, 4)];
    [_boxView addSubview:iView];
    iView.backgroundColor =[UIColor redColor];
    iView.alpha =.5;
    
//    _boxView.layer.borderColor = [UIColor greenColor].CGColor;
//    _boxView.layer.borderWidth = 1.0f;
    [self.view addSubview:_boxView];
    [_boxView.layer addSublayer:_scanLayer];
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2.5 target:self selector:@selector(moveScanLayer:) userInfo:nil repeats:YES];
    [timer fire];
    [self addMengBan];
}

- (void)addMengBan
{
    for (int i =0; i<4; i++) {
        UILabel *label =[UILabel new];
        [self.view addSubview:label];
        label.backgroundColor =[UIColor blackColor];
        //        label.backgroundColor =RGBA(200, 200, 200, .5);
        label.alpha =.5;
        if (i ==0) {
            label.frame =Frame(0, 64, WIDTH, _boxView.frame.origin.y-64);
        }else if (i==1){
            label.frame =Frame(0, _boxView.frame.origin.y, _boxView.frame.origin.x, _boxView.frame.size.height+0.2);
        }else if (i==2){
            label.frame =Frame(_boxView.frame.origin.x+_boxView.frame.size.width, _boxView.frame.origin.y, _boxView.frame.origin.x, _boxView.frame.size.height+0.2);
        }else{
            label.frame =Frame(0, _boxView.frame.origin.y+_boxView.frame.size.height, WIDTH, _boxView.frame.origin.y);
        }
    }
    
}
- (void)moveScanLayer:(NSTimer *)timer
{
    
    [iView donghua];
//    CGRect frame = _scanLayer.frame;
//    if (_boxView.frame.size.height < _scanLayer.frame.origin.y) {
//        frame.origin.y = 0;
//        _scanLayer.frame = frame;
//    }else{
//        frame.origin.y += 5;
//        [UIView animateWithDuration:0.1 animations:^{
//            _scanLayer.frame = frame;
//        }];
//    }
}

-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects.count>0) {
        [_session stopRunning];
        AVMetadataMachineReadableCodeObject *metadataObject = [metadataObjects objectAtIndex:0];
        //输出扫描字符串
        NSLog(@"%@",metadataObject.stringValue);
        
        if ([[metadataObject type] isEqualToString:AVMetadataObjectTypeQRCode]) {
            WebbViewController *webView = [[WebbViewController alloc]init];
//            webView.URL = [NSString stringWithFormat:@"%@&u=%@&k=%@",metadataObject.stringValue,[Singon deafauting].uid,[Singon deafauting].authKey];
//            NSLog(@"webView.URL === %@",webView.URL);
            [self.navigationController pushViewController:webView animated:YES];
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated. AVMetadataObjectTypeQRCode
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
