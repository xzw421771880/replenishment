//
//  detailSon.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/25.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "detailSon.h"

@implementation detailSon

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
//        self.layer.cornerRadius =5;
//        self.layer.masksToBounds =YES;
        self.backgroundColor=[UIColor whiteColor];
    }
    return self;
}

- (void)addAllViews
{
    self.titlelabel=[[UILabel alloc]initWithFrame:Frame(10, 0, 170, 30)];
    self.titlelabel.text=@"装箱单号 10000001";
    [self addSubview:self.titlelabel];
    
    self.dateLabel=[[UILabel alloc]initWithFrame:Frame(WIDTH-170, 0, 170, 30)];
    self.dateLabel.text=@"2018-01-01 12:12:11";
    self.dateLabel.font=FONT(14*DENGBI);
    self.dateLabel.textColor=RGB(150, 150, 150);
    [self.dateLabel rightWithJuli:10];//右对齐
    [self addSubview:self.dateLabel];
    
    self.numberLabel=[[UILabel alloc]initWithFrame:Frame(10, 30, 170, 30)];
    self.numberLabel.text=@"总量（包）  20";
    [self addSubview:self.numberLabel];
    
    self.detailLabel=[[UILabel alloc]initWithFrame:Frame(WIDTH-70, 28, 60, 30)];
    self.detailLabel.text=@"详情";
    self.detailLabel.textColor=[UIColor whiteColor];
    self.detailLabel.backgroundColor=HOMECOLOR;
    self.detailLabel.textAlignment=YES;
    self.detailLabel.layer.cornerRadius =5;
    self.detailLabel.layer.masksToBounds =YES;
    [self addSubview:self.detailLabel];
    
    [self addFooterLine];
}




@end
