//
//  Dai_bu_huoCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "Dai_bu_huoCell.h"

@implementation Dai_bu_huoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
