//
//  Que_renTableViewCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol Que_renTableViewCellDelegate <NSObject>

- (void)sendLaShenNSIndex:(NSIndexPath *)index;//拉伸
- (void)sendQueRenNSIndex:(NSIndexPath *)index;//确认
- (void)sendNSIndex:(NSIndexPath *)index andDetailLabel:(UIView *)detailLabel;//详情

@end

@interface Que_renTableViewCell : UITableViewCell

@property (nonatomic,assign)id<Que_renTableViewCellDelegate>deleagte;

@property(nonatomic,strong)UILabel * titleLabel;//标题
@property(nonatomic,strong)UILabel * queRenLabel;//确认收货
@property(nonatomic, strong)UIImageView *statusImage;//收展状态

@property(nonatomic, strong)UIView *detailView;//详情

@property(nonatomic, strong)NSIndexPath *index;//控件坐标

@property(nonatomic, assign)BOOL selete;

@property(nonatomic, strong)NSArray *detaiAry;//详情信息

-(void)changeStatus;

@end
