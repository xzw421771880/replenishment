//
//  Dai_bu_huoCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Dai_bu_huoCell : UITableViewCell

@end
