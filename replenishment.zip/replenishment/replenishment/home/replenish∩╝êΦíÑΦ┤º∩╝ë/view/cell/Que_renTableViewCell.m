//
//  Que_renTableViewCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "Que_renTableViewCell.h"

#import "detailSon.h"

@implementation Que_renTableViewCell


#pragma mark - 新建cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addAllViews];
//        self.backgroundColor=[UIColor redColor];
        [self noOne];
    }
    return self;
}

#pragma mark - 给cell添加控件
-(void)addAllViews
{
    //详情
    self.detailView=[[UIView alloc]init];
    [self addSubview:self.detailView];
    
    self.titleLabel=[[UILabel alloc]initWithFrame:Frame(10, 10, 150, 20)];
    self.titleLabel.text=@"快递编号1000001";
    [self addSubview:self.titleLabel];
    
    self.queRenLabel=[[UILabel alloc]initWithFrame:Frame(WIDTH-160, 5, 100, 30)];
    self.queRenLabel.text=@"确认收货";
    self.queRenLabel.textAlignment=YES;
    self.queRenLabel.backgroundColor=HOMECOLOR;
    self.queRenLabel.layer.cornerRadius =5;
    self.queRenLabel.layer.masksToBounds =YES;
    self.queRenLabel.textColor=[UIColor whiteColor];
    [self addSubview:self.queRenLabel];
    
    UITapGestureRecognizer *qRtap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(queRenTapAction:)];
    self.queRenLabel.userInteractionEnabled=YES;
    [self.queRenLabel addGestureRecognizer:qRtap];
    
    
    
    self.statusImage=[[UIImageView alloc]initWithFrame:Frame(WIDTH-40, 10, 20, 20)];
    [self.statusImage keep];
    [self addSubview:self.statusImage];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    self.statusImage.userInteractionEnabled=YES;
    [self.statusImage addGestureRecognizer:tap];
    
    [self addFooterLine:40];
}



#pragma mark - 确认收货

-(void)queRenTapAction:(UITapGestureRecognizer *)sender
{
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendQueRenNSIndex:)]) {
        [_deleagte sendQueRenNSIndex:self.index];
    }
}


#pragma mark - 状态
-(void)tapAction:(UITapGestureRecognizer *)sender
{
    //    self.selete=!self.selete;
    //    [self changeStatus];
    
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendLaShenNSIndex:)]) {
        [_deleagte sendLaShenNSIndex:self.index];
    }
}


-(void)changeStatus
{
    if (self.selete) {
        self.detailView.hidden=NO;
        [self detailViewShow];
        self.statusImage.image=[UIImage imageNamed:@"xia_la"];
    }else{
        self.detailView.hidden=YES;
        self.statusImage.image=[UIImage imageNamed:@"xia_la_wei"];
    }
}


-(void)detailViewShow
{
    //移出所有子视图
    [self.detailView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.detailView.frame=Frame(0, 40, WIDTH, self.detaiAry.count*60);//frame必须重置
    for (int i=0; i<self.detaiAry.count; i++) {
        detailSon *sonview =[[detailSon alloc]initWithFrame:Frame(0, i*60, WIDTH, 60)];

        [self.detailView addSubview:sonview];
        sonview.tag=i+1;
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(detailTapAction:)];
        sonview.detailLabel.userInteractionEnabled=YES;
        [sonview.detailLabel addGestureRecognizer:tap];
        
    }
    

}


#pragma mark - 详情
-(void)detailTapAction:(UITapGestureRecognizer *)sender
{
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendNSIndex:andDetailLabel:)]) {
        [_deleagte sendNSIndex:self.index andDetailLabel:sender.view];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
