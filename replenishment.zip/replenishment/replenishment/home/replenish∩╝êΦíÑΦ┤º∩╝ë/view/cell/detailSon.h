//
//  detailSon.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/25.
//  Copyright © 2018年 肖中旺. All rights reserved.
//


//装箱单号
#import <UIKit/UIKit.h>

@interface detailSon : UIView

@property(nonatomic, strong)UILabel *titlelabel;//装箱单号
@property(nonatomic, strong)UILabel *dateLabel;//日期
@property(nonatomic, strong)UILabel *numberLabel;//取货数量
@property(nonatomic, strong)UILabel *detailLabel;//详情

@end
