//
//  Bu_detailTableViewCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol detailCellDelegate <NSObject>

- (void)sendDetailNSIndex:(NSIndexPath *)index;//确认

@end
@interface Bu_detailTableViewCell : UITableViewCell

@property (nonatomic,assign)id<detailCellDelegate>deleagte;

@property(nonatomic, strong)NSIndexPath *index;//控件坐标



@end
