//
//  Bu_detailTableViewCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "Bu_detailTableViewCell.h"

#import "detailSon.h"

@implementation Bu_detailTableViewCell


#pragma mark - 新建cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addAllViews];
        //        self.backgroundColor=[UIColor redColor];
        [self noOne];
    }
    return self;
}

#pragma mark - 给cell添加控件
-(void)addAllViews
{
    detailSon *sonview =[[detailSon alloc]initWithFrame:Frame(0, 0, WIDTH, 60)];
    
    [self addSubview:sonview];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(detailTapAction:)];
    sonview.detailLabel.userInteractionEnabled=YES;
    [sonview.detailLabel addGestureRecognizer:tap];
    
}


#pragma mark - 详情
-(void)detailTapAction:(UITapGestureRecognizer *)sender
{
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendDetailNSIndex:)]) {
        [_deleagte sendDetailNSIndex:self.index];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
