//
//  bhTitle.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "bhTitle.h"
#import "sonTitle.h"

@implementation bhTitle

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.imageArray=@[@"dai_qu_huo",@"dai_buhuo",@"yi_chang",@"dai_shangshui"];
        self.titleArray=@[@"待取货（箱）",@"待补货（台）",@"异常",@"待上水（台）"];
        //        [self add_views:arry];
        [self addAllViews];
    }
    return self;
}
#pragma mark - 添加控件
-(void)addAllViews
{
    for (int i=0; i<self.titleArray.count; i++) {
        
        sonTitle *son=[[sonTitle alloc]initWithFrame:Frame(i*self.frame.size.width/4, 0, self.frame.size.width/self.titleArray.count, self.frame.size.height)];
        son.tag=i+1;
        son.titleLabel.text=self.titleArray[i];
        [self addSubview:son];
        
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
        son.userInteractionEnabled=YES;
        [son addGestureRecognizer:tap];
        

    }
    [self addselfFooterLine];
    [self backgroundChange:0];
}

-(void)tapAction:(UITapGestureRecognizer *)sender
{
    [self backgroundChange:(int)sender.view.tag-1];
    
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendButIndex:)]) {
        [_deleagte sendButIndex:(int)sender.view.tag-1];
    }
}

#pragma mark - 改变背景
-(void)backgroundChange:(int )index
{
    for (int i=0; i<self.titleArray.count; i++) {
        sonTitle *son=[(sonTitle *)self viewWithTag:i+1];

        if (index==i) {
            [self xuanYes:son];

        }else
            [self xuanNo:son];

    }
}


//选中
-(void)xuanYes:(sonTitle *)view
{
    view.imageView.image=[UIImage imageNamed:[NSString stringWithFormat:@"%@_xuan",self.imageArray[view.tag-1]]];
    view.titleLabel.textColor=HOMECOLOR;
}
//未选中
-(void)xuanNo:(sonTitle *)view
{
    view.imageView.image=[UIImage imageNamed:[NSString stringWithFormat:@"%@_wei",self.imageArray[view.tag-1]]];
    view.titleLabel.textColor=[UIColor grayColor];;
}



@end
