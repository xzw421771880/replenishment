//
//  bhTitle.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol bhTitleDelegate <NSObject>

- (void)sendButIndex:(NSInteger)indexNum;

@end
@interface bhTitle : UIView



@property(nonatomic,strong)NSArray *imageArray;
@property(nonatomic,strong)NSArray *titleArray;

@property (nonatomic,assign)id<bhTitleDelegate>deleagte;

-(void)backgroundChange:(int )index;


@end
