//
//  sonTitle.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "sonTitle.h"

@implementation sonTitle

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        //        [self add_views:arry];
        [self addAllViews];
    }
    return self;
}
#pragma mark - 添加控件
-(void)addAllViews
{
    self.imageView=[[UIImageView alloc]initWithFrame:Frame(15, 0, self.frame.size.width-30, self.frame.size.width-30)];
    [self addSubview:self.imageView];
    
    self.titleLabel=[[UILabel alloc]initWithFrame:Frame(0, self.frame.size.width-20, self.frame.size.width, 20)];
    self.titleLabel.textAlignment=YES;
    self.titleLabel.font=FONT(13*DENGBI);
    [self addSubview:self.titleLabel];
}

@end
