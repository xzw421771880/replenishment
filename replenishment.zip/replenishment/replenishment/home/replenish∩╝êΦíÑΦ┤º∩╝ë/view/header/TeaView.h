//
//  TeaView.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TeaViewDelegate <NSObject>

- (void)sendTeaView:(UIView *)view;

@end

@interface TeaView : UIView

@property (nonatomic,assign)id<TeaViewDelegate>deleagte;


@property(nonatomic, strong)UIImageView *TitleImage;//  标志
@property(nonatomic, strong)UILabel *titleLabel;//状态
@property(nonatomic, strong)UILabel *numberLabel;//取货数量
@property(nonatomic, strong)UIImageView *statusImage;//收展状态

@property(nonatomic, assign)BOOL selete;

-(void)changeStatus;


@end
