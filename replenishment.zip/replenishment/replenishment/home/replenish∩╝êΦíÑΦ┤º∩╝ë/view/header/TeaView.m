//
//  TeaView.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/24.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "TeaView.h"

@implementation TeaView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
//        self.layer.cornerRadius =5;
//        self.layer.masksToBounds =YES;
        self.backgroundColor=[UIColor whiteColor];
    }
    return self;
}

- (void)addAllViews
{
    self.TitleImage=[[UIImageView alloc]initWithFrame:Frame(10, 10, self.frame.size.height-20, self.frame.size.height-20)];
    self.TitleImage.image=[UIImage imageNamed:@"sou_suo"];
    [self.TitleImage keep];
    [self addSubview:self.TitleImage];
    
    
    self.titleLabel=[[UILabel alloc]initWithFrame:Frame(self.frame.size.height+5, 10, 80, self.frame.size.height-20)];
    self.titleLabel.text=@"茶叶";
    self.titleLabel.font=FONT(16*DENGBI);
    [self addSubview:self.titleLabel];
    
    
    self.numberLabel=[[UILabel alloc]initWithFrame:Frame(self.frame.size.width/2, 10, self.frame.size.width-self.frame.size.height, self.frame.size.height-20)];
    self.numberLabel.text=@"总取货：3箱80包";
    self.numberLabel.font=FONT(14*DENGBI);
    self.numberLabel.textColor=RGB(150, 150, 150);
    [self addSubview:self.numberLabel];
    
    
    self.statusImage=[[UIImageView alloc]initWithFrame:Frame(self.frame.size.width-self.frame.size.height+20, 20, self.frame.size.height-40, self.frame.size.height-40)];
    [self.statusImage keep];
    [self addSubview:self.statusImage];
//    [self changeStatus];
    
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    self.userInteractionEnabled=YES;
    [self addGestureRecognizer:tap];
    
    
    [self addFooterLine];

}

-(void)tapAction:(UITapGestureRecognizer *)sender
{
//    self.selete=!self.selete;
//    [self changeStatus];
    
    if (_deleagte &&[_deleagte respondsToSelector:@selector(sendTeaView:)]) {
        [_deleagte sendTeaView:self];
    }
}

-(void)changeStatus
{
    if (self.selete) {
        self.statusImage.image=[UIImage imageNamed:@"xia_la"];
    }else{
        self.statusImage.image=[UIImage imageNamed:@"xia_la_wei"];
    }
}



@end
