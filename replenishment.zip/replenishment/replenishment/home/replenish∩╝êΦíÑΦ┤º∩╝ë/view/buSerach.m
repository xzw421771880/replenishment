//
//  buSerach.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "buSerach.h"

@implementation buSerach

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
        self.layer.cornerRadius =5;
        self.layer.masksToBounds =YES;
        self.backgroundColor=RGB(230, 230, 230);
    }
    return self;
}

- (void)addAllViews
{
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:Frame(10, (self.frame.size.height-20)/2, 20, 20)];
    [imageView keep];
    imageView.image=[UIImage imageNamed:@"sou_suo"];
    [self addSubview:imageView];
    
    self.textField=[[UITextField alloc]initWithFrame:Frame(45, 5, self.frame.size.width-80, self.frame.size.height-10)];
    self.textField.placeholder=@"请输入快递单号";
    [self addSubview:self.textField];
    
}

@end
