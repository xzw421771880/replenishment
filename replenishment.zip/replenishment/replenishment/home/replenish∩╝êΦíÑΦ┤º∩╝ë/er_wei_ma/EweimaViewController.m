//
//  EweimaViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "EweimaViewController.h"

@interface EweimaViewController ()
{
    UIImageView *maImage;
}

@end

@implementation EweimaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    // Do any additional setup after loading the view.
    [self addMalog];
}

-(void)addMalog
{
    maImage=[[UIImageView alloc]initWithFrame:Frame(20, 100, WIDTH-40, WIDTH-40)];
    maImage.image=[UIImage imageNamed:@"ma_log"];
    [self.view addSubview:maImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
