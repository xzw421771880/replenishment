//
//  MyHeaderCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyHeaderCell : UITableViewCell

@property(nonatomic, strong)UIImageView *titleImageView;//用户头像
@property(nonatomic, strong)UILabel *titleLabel;//驿站补货
@property(nonatomic, strong)UILabel *nameLabel;//身份

@end
