//
//  MyHeaderCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "MyHeaderCell.h"

@implementation MyHeaderCell


#pragma mark - 新建cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addAllViews];
        //        self.backgroundColor=[UIColor redColor];
        [self noOne];
    }
    return self;
}

#pragma mark - 给cell添加控件
-(void)addAllViews
{
    self.titleImageView=[[UIImageView alloc]initWithFrame:Frame(10, 10, 60, 60)];
    self.titleImageView.backgroundColor=[UIColor redColor];
    [self.titleImageView circle];//圆
    [self addSubview:self.titleImageView];
    
    self.titleLabel=[[UILabel alloc]initWithFrame:Frame(80, 10, 160, 20)];
    self.titleLabel.text=@"驿站补货";
    self.titleLabel.font=FONT(16*DENGBI);
    [self addSubview:self.titleLabel];
    
    self.nameLabel=[[UILabel alloc]initWithFrame:Frame(80, 50, 100, 20)];
    self.nameLabel.text=@"补水员";
    self.nameLabel.textColor=[UIColor grayColor];
    self.nameLabel.font=FONT(13*DENGBI);
    [self addSubview:self.nameLabel];
    
    [self addFooterLine:80];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
