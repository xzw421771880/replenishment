//
//  MineViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/21.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "MineViewController.h"

#import "MineCell.h"
#import "MyHeaderCell.h"

#import "RecordViewController.h"//补货记录
#import "ChangePwViewController.h"//修改密码
#import "GuideViewController.h"//补货指南
#import "FeedBackViewController.h"//反馈意见
#import "GoodBreakViewController.h"//物品报损
#import "LeaveViewController.h"//请假
#import "OpenWordViewController.h"//申请开门码


@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>

{
    UITableView *myTableView;
    
    NSMutableDictionary *userDic;
    
    NSArray *titleAry;
}

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.automaticallyAdjustsScrollViewInsets=NO;
    userDic =[self getUser];
    if ([userDic[@"pw"] isEqualToString:@"1"]) {
        titleAry=@[@"补货记录",@"修改密码",@"补货指南",@"反馈意见",@"物品报损",@"请假",@"申请开门码",@"退出"];
    }else{
        titleAry=@[@"反馈意见",@"退出"];
    }
    [self addaTableView];
    // Do any additional setup after loading the view.
}


#pragma mark - 添加待取货
- (void)addaTableView
{
    myTableView =[[UITableView alloc]initWithFrame:Frame(0, 64, WIDTH, HEIGHT-64)];
    [self.view addSubview:myTableView];
    myTableView.delegate =self;
    myTableView.dataSource =self;
    [myTableView quXian];
    [myTableView registerClass:[MineCell class] forCellReuseIdentifier:@"MineCell"];
    [myTableView registerClass:[MyHeaderCell class] forCellReuseIdentifier:@"MyHeaderCell"];
    
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section==0) {
        return 1;
    }else{
        
        return titleAry.count;
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        
        MyHeaderCell *cell =[tableView dequeueReusableCellWithIdentifier:@"MyHeaderCell" forIndexPath:indexPath];
        
        //    cell.dataDic =aDataArr[indexPath.row];
        return cell;
    }else
    {
        MineCell *cell =[tableView dequeueReusableCellWithIdentifier:@"MineCell" forIndexPath:indexPath];
        
        cell.titleLabel.text=titleAry[indexPath. row];
        //    cell.dataDic =aDataArr[indexPath.row];
        return cell;
    }
    
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        return 80;
    }else{
        return 50;
    }
    
    
}






- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([userDic[@"pw"] isEqualToString:@"1"]) {
        if (indexPath.section==1) {
            if (indexPath.row==0) {//补货记录
                RecordViewController *vc=[[RecordViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==1){//修改密码
                ChangePwViewController *vc=[[ChangePwViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==2){//补货指南
                GuideViewController *vc=[[GuideViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==3){//反馈意见
                FeedBackViewController *vc=[[FeedBackViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==4){//物品报损
                GoodBreakViewController *vc=[[GoodBreakViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==5){//请假
                LeaveViewController *vc=[[LeaveViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==6){//申请开门码
                OpenWordViewController *vc=[[OpenWordViewController alloc]init];
                self.hidesBottomBarWhenPushed =YES;
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed =NO;
            }else if (indexPath.row==7){
                
            }
            
        }
    }else{
        
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
