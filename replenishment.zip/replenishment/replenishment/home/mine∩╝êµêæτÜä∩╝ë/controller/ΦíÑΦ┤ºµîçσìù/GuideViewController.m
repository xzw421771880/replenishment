//
//  GuideViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "GuideViewController.h"
#import "UIWebView+Load.h"

#import <WebKit/WebKit.h>

@interface GuideViewController ()

@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"补货指南";
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self addWebView];
    // Do any additional setup after loading the view.
}

- (void)addWebView
{
    //    UIWebView * webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, WIDTH, HEIGHT - 64)];
    //    webView.delegate = self;
    ////    NSString *str= [NSString stringWithFormat:@"%@/mapi/m/news.aspx?id=",HTTP];
    ////    NSLog(@"======%@", str);
    //    [webView loadViewWithStr:[NSString stringWithFormat:@"%@taxi_passenger/newsShow.faces?newsId=9",HTTP]];
    ////    [webView loadViewWithStr:[NSString stringWithFormat:@"%@%@?driverId=1",HTTP, INPURSE]];
    //
    //    [self.view addSubview:webView];
    
    WKWebView *webView = [[WKWebView alloc] initWithFrame:self.view.bounds];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@taxi_passenger/newsShow.faces?newsId=9",@"http"]]]];
    [self.view addSubview:webView];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
