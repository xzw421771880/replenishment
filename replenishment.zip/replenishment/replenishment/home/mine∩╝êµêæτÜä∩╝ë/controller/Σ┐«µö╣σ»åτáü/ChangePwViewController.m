//
//  ChangePwViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "ChangePwViewController.h"

#import "XZW_textField.h"

@interface ChangePwViewController ()<UITextFieldDelegate>

{
    XZW_textField *oldPw;
    XZW_textField *newPw;
    XZW_textField *reNewPw;
    
}

@end

@implementation ChangePwViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"修改密码";
    self.view.backgroundColor=[UIColor whiteColor];
    [self addTextField];
    [self addNext];
    
    
    // Do any additional setup after loading the view.
}


-(void)addTextField
{
    NSArray *titleAry=@[@"请输入原密码",@"请输入新密码",@"请再次输入新密码"];
    NSArray *imageAry=@[@"login_password",@"login_password",@"login_password"];
    for (int i=0; i<3; i++) {
        XZW_textField *xzw=[[XZW_textField alloc]initWithFrame:Frame(25, 100+i*55, WIDTH-50, 45)];
        [self.view addSubview:xzw];
        xzw.layer.cornerRadius =5;
        xzw.layer.masksToBounds =YES;
        xzw.textField.secureTextEntry=YES;
        xzw.textField.delegate=self;
        xzw.backgroundColor=[UIColor whiteColor];
        xzw.textField.placeholder=titleAry[i];
        xzw.textField.keyboardType =UIKeyboardTypeASCIICapable;
        xzw.imageView.image=[UIImage imageNamed:imageAry[i]];
        xzw.textField.keyboardType =UIKeyboardTypeASCIICapable;
        if (i==0) {
            oldPw=xzw;
        }else if(i==1){
            newPw=xzw;
        }else
        {
            reNewPw=xzw;
        }
        
    }
}

-(void)addNext
{
    UIButton *but =[UIButton buttonWithType:UIButtonTypeCustom];
    but.frame=Frame(25, 410, WIDTH-50, 40);
    [but setTitle:@"确认修改" forState:UIControlStateNormal];
    but.layer.cornerRadius =5;
    but.layer.masksToBounds =YES;
    but.backgroundColor=HOMECOLOR;
    [but setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [but addTarget:self action:@selector(nextAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:but];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"ddd");
    [self.view endEditing:YES];
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
}

#pragma mark - UITextViewDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"%f==%f==%f",textField.superview.frame.size.height,textField.superview.frame.origin.y,HEIGHT-216);
    if (textField.superview.frame.size.height+textField.superview.frame.origin.y>HEIGHT-260) {
        self.view.frame=Frame(0, HEIGHT-260-textField.superview.frame.size.height-textField.superview.frame.origin.y, WIDTH, 260+textField.superview.frame.size.height+textField.superview.frame.origin.y);
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
    [textField resignFirstResponder];
    return YES;
}
-(void)nextAction
{
    if (oldPw.textField.text.length==0) {
        [self alertWith:@"请输入密码"];
        return;
    }
    if (newPw.textField.text.length<6) {
        [self alertWith:@"密码长度最少6位数"];
        return;
    }
    if (reNewPw.textField.text.length==0) {
        [self alertWith:@"请输入新密码"];
        return;
    }
    
    if (reNewPw.textField.text.length==0) {
        [self alertWith:@"请再次输入新密码"];
        return;
    }
    if ([newPw.textField.text isEqualToString:reNewPw.textField.text]) {
        [self alertWith:@"两次新密码输入不一致"];
        return;
    }
    
//    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:self.phoneNumeber,@"phoneNum",
//                            self.code,@"verificationCode",@1,@"isLogin",self.imagecode,@"checkNum",self.passView.textField.text,@"pwd",
//                            nil];
//    [[NetWorkEngine shareNetWorkEngine] netWorkWith:CHECKCODE withParam:params WithSuccessBlock:^(id obj) {
//
//        NSData *JSONData = [obj dataUsingEncoding:NSUTF8StringEncoding];
//        NSError *err;
//        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingMutableContainers error:&err];
//        if(err) {
//            NSLog(@"json解析失败：%@",err);
//        }
//        NSLog(@"%@==",json);
//        if ([json[@"code"] isEqualToString:@"1"]) {
//            [self alertWith:@"修改成功"];
//            [self changeSuccess];
//        }
//        //        [self pushTwo];
//
//    } withFailBlock:^(id obj) {
//        [self alertWith:(NSString *)obj];
//    }];
    
}

- (void)changeSuccess
{
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
