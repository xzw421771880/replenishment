//
//  FeedBackViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "FeedBackViewController.h"

@interface FeedBackViewController ()<UITextViewDelegate>
{
    
    UILabel *textLabel;
}

@property (nonatomic, strong)UITextView * mainText;
@property (nonatomic, strong)UIButton * finishBut;
@property (nonatomic, strong)UILabel * headerLable;

@end

@implementation FeedBackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"反馈意见";
    self.view.backgroundColor=[UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets=NO;
    [self.view addSubview:self.mainText];
    [self.view addSubview:self.finishBut];
    [self.view addSubview:self.headerLable];
    // Do any additional setup after loading the view.
}



- (UITextView *)mainText
{
    if (!_mainText) {
        self.mainText = [[UITextView alloc] initWithFrame:CGRectMake(10, 113, WIDTH-20, HEIGHT / 2 - 103)];
        self.mainText.delegate = self;
        self.mainText.font=FONT(15*DENGBI);
        self.mainText.layer.borderWidth=.6;
        self.mainText.layer.borderColor=RGB(200, 200, 200).CGColor;
        [self.mainText circle:10];
        _mainText.keyboardType = UIKeyboardTypeDefault;
        _mainText.returnKeyType = UIReturnKeyDone;
        textLabel =[[UILabel alloc]initWithFrame:Frame(5, 5, WIDTH -15, 20)];
        textLabel.text =@"写下你想对我们说的...";
        textLabel.textColor =[UIColor grayColor];
        [_mainText addSubview:textLabel];
        //        self.mainText.text = @"想对我们说点什么...";
    }
    return _mainText;
}

- (UIButton *)finishBut
{
    if (!_finishBut) {
        self.finishBut = [UIButton buttonWithType:UIButtonTypeCustom];
        self.finishBut.frame = CGRectMake(15, HEIGHT / 2 + 30, WIDTH - 30, 40);
        self.finishBut.layer.cornerRadius = 10;
        self.finishBut.layer.masksToBounds = YES;
        self.finishBut.backgroundColor = HOMECOLOR;
        [self.finishBut setTitle:@"提交" forState:UIControlStateNormal];
        [self.finishBut setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.finishBut.backgroundColor = HOMECOLOR;
        [self.finishBut addTarget:self action:@selector(finishButClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _finishBut;
}


- (void)finishButClicked:(UIButton *)sender
{
//    //http://huaxin.clzglass.com/mapi/UserApi.asmx/UserFeedBackAdd
//    [self.mainText resignFirstResponder];
//    NSDictionary * parameters = @{@"realname":[Singon deafauting].relName, @"uid":[Singon deafauting].uid, @"title":@"反馈标题", @"content":self.mainText.text};
//    [[NetWorkEngine shareNetWorkEngine] postInfoFromServerWithUrlStr:[NSString stringWithFormat:@"%@/mapi/UserApi.asmx/UserFeedBackAdd", BASEURL] Paremeters:parameters successOperation:^(id response) {
//        _mainText.text=@"";
//        NSString *message =[NSString stringWithFormat:@"%@",response[@"message"]];
//        NSString *messagestr =[NSString stringWithFormat:@"%@",response[@"messagestr"]];
//        if ([message isEqualToString:@"1"]) {
//            [self.navigationController popViewControllerAnimated:YES];
//            [SVProgressHUD showInfoWithStatus:messagestr];
//        }
//        if ([message isEqualToString:@"2"]) {
//            [self.navigationController popViewControllerAnimated:YES];
//            [SVProgressHUD showSuccessWithStatus:messagestr];
//            [self leftButtonAction];
//        }
//
//    } failoperation:^(NSError *error) {
//
//    }];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"ddd");
    [self.mainText resignFirstResponder];
}
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    //    if ([textView.text isEqualToString:@"想对我们说点什么..."]) {
    //        textView.text = @"";
    //    }
    //    textView.keyboardType = UIKeyboardAppearanceDark;
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    //    if (textView.text.length<1) {
    //        textView.text = @"想对我们说点什么...";
    //    }
    [textView resignFirstResponder];
    
}

- (void)textViewDidChange:(UITextView *)textView
{
    if (textView.text.length ==0) {
        textLabel.hidden =NO;
    }else{
        textLabel.hidden =YES;
    }
    NSLog(@"-----%@", textView.text);
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]){ //判断输入的字是否是回车，即按下return
        //在这里做你响应return键的代码
        [textView resignFirstResponder];
        return NO; //这里返回NO，就代表return键值失效，即页面上按下return，不会出现换行，如果为yes，则输入页面会换行
    }
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
