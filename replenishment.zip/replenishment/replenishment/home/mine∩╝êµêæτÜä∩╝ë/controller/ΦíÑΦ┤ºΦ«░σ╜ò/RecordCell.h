//
//  RecordCell.h
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordCell : UITableViewCell


@property(nonatomic,strong)UILabel * serLabel;//序号
@property(nonatomic,strong)UILabel * robLabel;//机器编号
@property(nonatomic,strong)UILabel * shopLabel;//商品
@property(nonatomic,strong)UILabel * numberLabel;//数量
@property(nonatomic,strong)UILabel * dateLabel;//到货时间


@end
