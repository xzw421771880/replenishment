//
//  RecordViewController.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "RecordViewController.h"

#import "MyPicker.h"

#import "RecordCell.h"

@interface RecordViewController ()<MypickerDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UILabel *startPicker;//开始时间
    UILabel *endPicker;//结束时间
    
    UILabel *seleteLabel;//选择
    
    UITableView *myTableView;
    
    NSMutableArray *dateAry;
}

@end

@implementation RecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"补货记录";
    self.view.backgroundColor=[UIColor whiteColor];
//    [self addPicker];
    [self addSeleteLabel];
    [self addTableView];
    // Do any additional setup after loading the view.
}


- (void)addSeleteLabel
{
    UIView * titleView=[[UIView alloc]initWithFrame:Frame(0, 80, WIDTH, 50)];
    [self.view addSubview:titleView];
    
    startPicker=[[UILabel alloc]initWithFrame:Frame(10, 10, WIDTH/2-20, 35)];
    startPicker.text=@"开始时间：";
    [startPicker circle:10];
    [startPicker keep];
    startPicker.backgroundColor=[UIColor grayColor];
    startPicker.textAlignment=YES;
    [titleView addSubview:startPicker];
    
    endPicker=[[UILabel alloc]initWithFrame:Frame(WIDTH/2+10, 10, WIDTH/2-20, 35)];
    endPicker.text=@"结束时间：";
    [endPicker circle:10];
    endPicker.backgroundColor=[UIColor grayColor];
    endPicker.textAlignment=YES;
    [titleView addSubview:endPicker];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addPicker:)];
    startPicker.userInteractionEnabled=YES;
    [startPicker addGestureRecognizer:tap];
    
    UITapGestureRecognizer *tap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addPicker:)];
    endPicker.userInteractionEnabled=YES;
    [endPicker addGestureRecognizer:tap1];
}

- (void)addPicker:(UITapGestureRecognizer *)sender
{
    seleteLabel =(UILabel *)sender.view;
    MyPicker *pic=[[MyPicker alloc]initWithFrame:Frame(10, HEIGHT-200, WIDTH-20, 200)];
    pic.deleagte=self;
    [pic Show];
//    [self.view addSubview:alert];

}

#pragma mark - MyPickeDelegate
-(void)sendDate:(NSString *)date
{
    seleteLabel.text=date;//选中后赋值
    seleteLabel.textColor=[UIColor whiteColor];
    seleteLabel.backgroundColor=HOMECOLOR;
}

#pragma mark - 添加待取货
- (void)addTableView
{
    myTableView =[[UITableView alloc]initWithFrame:Frame(0, 140, WIDTH, HEIGHT-140)];
    [self.view addSubview:myTableView];
    myTableView.delegate =self;
    myTableView.dataSource =self;
    [myTableView quXian];
    [myTableView registerClass:[RecordCell class] forCellReuseIdentifier:@"RecordCell"];
   
    
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
   
    return 10;
//    return dateAry.count;
    
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    
    
    RecordCell *cell =[tableView dequeueReusableCellWithIdentifier:@"RecordCell" forIndexPath:indexPath];
        
        //    cell.dataDic =aDataArr[indexPath.row];
    return cell;
   
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
        UIView *v=[[UIView alloc]initWithFrame:Frame(0, 0, WIDTH, 60)];
        v.backgroundColor=[UIColor whiteColor];
    
    for (int i=0; i<5; i++) {
        UILabel *label=[[UILabel alloc]initWithFrame:Frame(0, 0, WIDTH/8, 60)];
        label.textAlignment=YES;
        label.font=FONT(10*DENGBI);
        [v addSubview:label];
        if (i==0) {
            label.text=@"序号";
            label.frame=Frame(0, 0, WIDTH/8, 60);
        }else if (i==1){
            
            label.text=@"机器编号";
            label.frame=Frame(WIDTH/8, 0, WIDTH/4, 60);
        }else if (i==2){
            
            label.text=@"商品";
            label.frame=Frame(WIDTH/8*3, 0, WIDTH/4, 60);
        }else if (i==3){
            
            label.text=@"数量(包)";
            label.frame=Frame(WIDTH/8*5, 0, WIDTH/8, 60);
        }else if (i==4){
            label.text=@"到货时间";
            label.frame=Frame(WIDTH/4*3, 0, WIDTH/4, 60);
//            label.textColor=HOMECOLOR;
        }
    }
    return v;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
