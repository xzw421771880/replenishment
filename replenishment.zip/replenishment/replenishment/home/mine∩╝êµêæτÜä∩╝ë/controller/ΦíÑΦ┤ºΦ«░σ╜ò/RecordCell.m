//
//  RecordCell.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/26.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "RecordCell.h"

@implementation RecordCell


#pragma mark - 新建cell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addAllViews];
        //        self.backgroundColor=[UIColor redColor];
        [self noOne];
    }
    return self;
}

#pragma mark - 给cell添加控件
-(void)addAllViews
{
    
    for (int i=0; i<5; i++) {
        UILabel *label=[[UILabel alloc]initWithFrame:Frame(0, 0, WIDTH/8, 40)];
        label.text=@"01";
        label.textAlignment=YES;
        label.font=FONT(10*DENGBI);
        [self addSubview:label];
        if (i==0) {
            self.serLabel=label;
            self.serLabel.text=@"01";
            label.frame=Frame(0, 0, WIDTH/8, 40);
        }else if (i==1){
            self.robLabel=label;
            self.robLabel.text=@"1000000001";
            label.frame=Frame(WIDTH/8, 0, WIDTH/4, 40);
        }else if (i==2){
            self.shopLabel=label;
            self.shopLabel.text=@"天府茅台";
            label.frame=Frame(WIDTH/8*3, 0, WIDTH/4, 40);
        }else if (i==3){
            self.numberLabel=label;
            self.numberLabel.text=@"1";
            label.frame=Frame(WIDTH/8*5, 0, WIDTH/8, 40);
        }else if (i==4){
            self.dateLabel=label;
            self.dateLabel.text=@"2018/01/06 17:18";
            label.frame=Frame(WIDTH/4*3, 0, WIDTH/4, 40);
            label.textColor=HOMECOLOR;
        }
    }
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
